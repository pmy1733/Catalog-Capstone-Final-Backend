package com.meroka.SafaricomCatalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SafaricomCatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
